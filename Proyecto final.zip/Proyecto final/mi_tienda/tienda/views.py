from django.contrib.auth.models import User
from django.contrib.auth import logout, authenticate, login as auth_login
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Producto
from .forms import ProductForm  # Importa el formulario

def index(request):
    # Verificar si el usuario está autenticado y si es superusuario
    is_superuser = request.user.is_superuser if request.user.is_authenticated else False
    
    # Obtener todos los productos
    productos = Producto.objects.all()
    
    return render(request, 'tienda/index.html', {
        'is_superuser': is_superuser,
        'productos': productos
    })

def register(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Validaciones básicas
        if not username or not email or not password:
            messages.error(request, "Todos los campos son obligatorios.")
            return render(request, 'tienda/register.html')

        if password != confirm_password:
            messages.error(request, "Las contraseñas no coinciden.")
            return render(request, 'tienda/register.html')

        # Verificar si el usuario ya existe
        if User.objects.filter(username=username).exists():
            messages.error(request, "El nombre de usuario ya está en uso.")
            return render(request, 'tienda/register.html')

        # Crear el usuario
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Usuario registrado exitosamente. Ahora puedes iniciar sesión.")
        return redirect('login')  # Redirigir a la página de inicio de sesión

    return render(request, 'tienda/register.html')

def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Autenticar al usuario
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            messages.success(request, "Inicio de sesión exitoso.")
            return redirect('index')  # Redirigir a la página principal
        else:
            messages.error(request, "Nombre de usuario o contraseña incorrectos.")
            return render(request, 'tienda/login.html')

    return render(request, 'tienda/login.html')

def logout_view(request):
    logout(request)
    messages.success(request, "Has cerrado sesión exitosamente.")
    return redirect('index')  # Redirigir a la página principal

def contact(request):
    return render(request, 'tienda/contact.html')

def about(request):
    return render(request, 'tienda/about.html')

def products(request):
    return render(request, 'tienda/products.html')

# Proteger la vista de agregar productos solo para superusuarios
def is_superuser(user):
    return user.is_superuser

@login_required
@user_passes_test(is_superuser)

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)  # Maneja los archivos también
        if form.is_valid():
            form.save()  # Guarda el nuevo producto en la base de datos
            messages.success(request, "Producto agregado exitosamente.")
            return redirect('index')  # Redirige a la página principal después de agregar el producto
    else:
        form = ProductForm()  # Crea un formulario vacío

    return render(request, 'tienda/add_product.html', {'form': form})

def producto_agregado(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    return render(request, 'producto_agregado.html', {'producto': producto})

def agregar_al_carrito(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    carrito = request.session.get('carrito', {})

    if str(producto.id) in carrito:
        carrito[str(producto.id)]['cantidad'] += 1
    else:
        carrito[str(producto.id)] = {
            'nombre': producto.nombre,
            'precio': float(producto.precio),
            'cantidad': 1,
        }

    request.session['carrito'] = carrito
    print(request.session['carrito']) 
    return redirect('ver_carrito')

def ver_carrito(request):
    carrito = request.session.get('carrito', {})
    total = sum(item['precio'] * item['cantidad'] for item in carrito.values())
    return render(request, 'tienda/ver_carrito.html', {'carrito': carrito, 'total': total})

def eliminar_del_carrito(request, producto_id):
    carrito = request.session.get('carrito', {})
    if str(producto_id) in carrito:
        del carrito[str(producto_id)]
        request.session['carrito'] = carrito
    return redirect('ver_carrito')

def limpiar_carrito(request):
    request.session['carrito'] = {}
    return redirect('ver_carrito')

# views.py
def lista_productos(request):
    productos = Producto.objects.all()
    return render(request, 'tienda/lista_productos.html', {'productos': productos})

def buscar_producto(request):
    query = request.GET.get('query', '')
    productos = Producto.objects.filter(nombre__icontains=query)
    return render(request, 'tienda/index.html', {'productos': productos, 'query': query})
